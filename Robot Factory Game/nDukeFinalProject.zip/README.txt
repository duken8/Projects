Incomplete Functionality:
	-Robot moves smoothly between cells in sub-steps.
	-When correct, testing continues with next case after dialog dismissal.
	-When incorrect, game remains paused and starts over with the first test case when user restarts.
	-Notification is given when all test cases in the challenge are correct.
	-Game starts the challenge from the first case anytime user modifies playfield.
	-Game can be sped up and slowed down using cursor up and cursor down

I was unable to animate the robot smoothly and got hung up on how to use an AnimationTimer in a looping
fashion. My program can only test through the first test case, but is compatible with files that have many.
